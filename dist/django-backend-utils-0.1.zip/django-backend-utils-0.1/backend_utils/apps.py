from django.apps import AppConfig


class BackendUtilsConfig(AppConfig):
    name = 'backend_utils'
